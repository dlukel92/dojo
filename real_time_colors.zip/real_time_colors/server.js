const express = require("express");
const app = express();
app.use(express.static(__dirname + "/static"));
const server = app.listen(1337);
const io = require('socket.io').listen(server);
app.set('views', __dirname + '/views'); 
app.set('view engine', 'ejs');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: true}));

io.on('connection', function (socket) { //2
  
    socket.emit('greeting', { msg: 'Greetings, from server Node, brought to you by Sockets! -Server' }); //3
    
    socket.on('pink_clicked', function () { //7
      console.log("Server received pink click"); //8 (note: this log will be on your server's terminal)
      socket.broadcast.emit('pink_confirm')
    });
    socket.on('blue_clicked', function () { //7
        console.log("Server received blue click"); //8 (note: this log will be on your server's terminal)
        socket.broadcast.emit('blue_confirm')
      });
      socket.on('green_clicked', function () { //7
        console.log("Server received green click"); //8 (note: this log will be on your server's terminal)
        socket.broadcast.emit('green_confirm')
      });

  });

app.get('/', function(req, res) {

    res.render("index");
    
   });