const express = require("express");
const app = express();
app.use(express.static(__dirname + "/static"));
const server = app.listen(1337);
const io = require('socket.io') (server);
app.set('views', __dirname + '/views'); 
app.set('view engine', 'ejs');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: true}));
var rando = 0;
    
io.on('connection', function (socket) { //2
  
  socket.emit('greeting', { msg: 'Greetings, from server Node, brought to you by Sockets! -Server' }); //3
  socket.on('clicked', function (data) { //7
    console.log(data.name, data.location, data.language); //8 (note: this log will be on your server's terminal)
    socket.emit("sent", data)
  });
    
});
// root route to render the index.ejs view
app.get('/', function(req, res) {

  res.render("index");
  
 });
 