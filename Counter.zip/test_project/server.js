var express = require("express");
var session = require('express-session');
var bodyParser = require('body-parser');
var app = express();

app.use(session({
  secret: 'keyboardkitteh',
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 60000 }
}))

// use it!
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static(__dirname + "/static"));
// This sets the location where express will look for the ejs views
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
// root route




app.get('/', function (req, res){
    
    if (req.session.count == null){
        req.session.count = 1;
        console.log(req.session.count)
    }
    else{ req.session.count += 5;
        console.log(req.session.count);
    }
    res.render('index', {count: req.session.count});
  });






  // route to process new user form data:
  app.post('/users', function (req, res){
    console.log("POST DATA \n\n",req.body)
    req.session.count = req.body.name;
    console.log(req.session.count);
    res.redirect('/');
  })
  app.get("/users/:id", function (req, res){
    console.log("The user id requested is:", req.params.id);
    // just to illustrate that req.params is usable here:
    res.send("You requested the user with id: " + req.params.id);
    // code to get user from db goes here, etc...
});

app.listen(8000, function() {
    console.log("listening on port 8000");
  })