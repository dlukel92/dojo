// Load the express module and store it in the variable express (Where do you think this comes from?)
var express = require("express");

// invoke express and store the result in the variable app
var app = express();

// use app's get method and pass it the base route '/' and a callback
// app.get('/', function(request, response) {
//     // just for fun, take a look at the request and response objects

//    // use the response object's .send() method to respond with an h1
//    response.send("<h1>Hello Express</h1>");
// })
// tell the express app to listen on port 8000, always put this at the end of your server.js file
app.listen(8000, function() {
  console.log("listening on port 8000");
})
app.use(express.static(__dirname + "/static"));
// This sets the location where express will look for the ejs views
app.set('views', __dirname + '/views'); 
// Now lets set the view engine itself so that express knows that we are using ejs as opposed to another templating engine like jade
app.set('view engine', 'ejs');

app.get("/cars", function (request, response){
    response.render('cars');
})
app.get("/cats", function (request, response){
    response.render('cats');
})
app.get("/form", function (request, response){
    response.render('form');
})
app.get("/cat1", function (request, response){
    // hard-coded user data
    var stuffs= [
        {name: "Cool Cat", email: "iamakitty@codingdojo.com"},  
    ];
    response.render('details', {stuffs_array: stuffs});
})
app.get("/cat2", function (request, response){
    // hard-coded user data
    var stuffs= [
        {name: "Beach Cat", email: "imthebeachkitty@codingdojo.com"},  
    ];
    response.render('details', {stuffs_array: stuffs});
})
app.get("/cat3", function (request, response){
    // hard-coded user data
    var stuffs= [
        {name: "Picatchu", email: "picatchu@codingdojo.com"},  
    ];
    response.render('details', {stuffs_array: stuffs});
})


